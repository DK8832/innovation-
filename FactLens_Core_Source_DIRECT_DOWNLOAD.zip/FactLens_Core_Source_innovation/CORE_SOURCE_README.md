# FactLens 핵심 소스코드

- 팀명: innovation
- 작품명: FactLens (AI Auditor)
- 버전: 0.1.0
- 제출 소스 기준: Git commit `bb4d5b92ac2d19e57eb02e4027068827121f1ab4`
- 원본 공유 ZIP SHA-256: `a90064982f00fee36082d6097d8e6e254ada21a7ef8289806e7fe13e240c5edc`

## 작품의 핵심

FactLens는 생성형 AI 답변을 문장·절 단위 주장으로 분해한 뒤, 사용자가 제공한 독립 기준 문서와 대조하여 `SUPPORTED`, `CONTRADICTED`, `INSUFFICIENT`, `UNVERIFIABLE`의 네 상태로 설명하는 Codex/MCP Apps 플러그인이다. 현재 버전은 문서 기반 검증만 제공하며 인터넷 자동검색 기능은 포함하지 않는다.

## 핵심 파일 지도

| 경로 | 역할 |
|---|---|
| `plugins/factlens/server.mjs` | MCP 서버, 도구 등록, UI 자원, Python 실행 및 HTTP/stdio 전송 |
| `plugins/factlens/vendor/factlens/claims.py` | 문장·절 단위 주장 추출 및 원문 위치 보존 |
| `plugins/factlens/vendor/factlens/retrieval.py` | 기준 문서 문장 검색과 상위 근거 선정 |
| `plugins/factlens/vendor/factlens/text.py` | 정규화, 토큰·문자 2-gram 유사도, 숫자·부정 표현 처리 |
| `plugins/factlens/vendor/factlens/verifier.py` | 지지·모순·근거 부족·검증 불가 판정 |
| `plugins/factlens/vendor/factlens/scoring.py` | 상태 요약과 중요도 가중 위험도 계산 |
| `plugins/factlens/vendor/factlens/pipeline.py` | 추출→검색→판정→요약 파이프라인 |
| `plugins/factlens/vendor/factlens/models.py` | 요청·결과·근거 데이터 모델 |
| `plugins/factlens/scripts/analyze.py` | Node 서버와 Python 엔진 사이 JSON 입출력 진입점 |
| `plugins/factlens/ui/workbench.html` | 답변·기준 문서 입력 및 결과 시각화 작업창 |
| `plugins/factlens/skills/factlens/SKILL.md` | 독립 근거 확보→초안→검증→교정 운영 절차 |
| `plugins/factlens/.codex-plugin/plugin.json` | 플러그인 이름·버전·UI·Skill 선언 |
| `plugins/factlens/.mcp.json` | Codex용 MCP 서버 실행 설정 |
| `plugins/factlens/package.json` | 의존성, 빌드 및 실행 명령 |

## 빌드와 실행

Node.js 20 이상과 Python 3.11 이상을 준비한 뒤 다음 명령을 실행한다.

```bash
cd plugins/factlens
pnpm install --frozen-lockfile
pnpm run build
pnpm start
```

HTTP 모드는 빌드 후 다음과 같이 실행한다.

```bash
pnpm run start:http
```

`dist/server.mjs`는 `pnpm run build`로 생성되는 산출물이므로 핵심 소스코드 제출 ZIP에서는 제외했다.

## 제출 ZIP에서 제외한 항목

- 생성 번들: `dist/`
- 설치 편의 파일: 루트 `INSTALL.cmd`
- 배포 보조: `Dockerfile`, `.dockerignore`
- 공개·스토어 제출 문서: `PUBLICATION.md`, `chatgpt-app-submission.json`
- 테스트 보조 스크립트와 마켓플레이스 메타데이터

아이콘 3종은 플러그인 선언 파일이 직접 참조하는 필수 인터페이스 자산이므로 포함했다.
